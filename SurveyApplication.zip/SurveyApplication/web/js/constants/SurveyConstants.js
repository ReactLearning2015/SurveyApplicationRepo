/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var keyMirror = require('keymirror');

module.exports = keyMirror({
  SAVE_ANSWER: null,
  SAVE_SURVEY: null,
  VIEW_COMPLETED_SURVEY: null,
  CLEAR_QUESTIONNAIRE: null,
  LOAD_QNDA: null
});

